package com.citiustech.ApplicationEntities;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.regex.Pattern;

public class Customer extends TradingPartner implements Serializable {

	private static final long serialVersionUID = 2025683977287910349L;
	public Long customerId;
	public Long creditLimit;
	public String emailId;

	@Override
	public ArrayList<String> validate() {
		ArrayList<String> tradingErrors = super.validate();
		ArrayList<String> errorList;
		try {
			if (tradingErrors != null && !tradingErrors.isEmpty()) {
				errorList = tradingErrors;
			} else {
				errorList = new ArrayList<String>();
			}

			if (getCreditLimit() > 50000) {
				errorList.add("Credit Limit should not be more than 50,000");
			}
			if (!isEmailValid(getEmailId())) {
				errorList.add("Invalid Email Id");
			}
			return errorList;
		} catch (Exception e) {
			System.err.println("ERROR WHILE VALIDATING CUSTOMER : ");
			System.err.println(e);
			return null;
		}
	}

	public static boolean isEmailValid(String email) {
		String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\." + "[a-zA-Z0-9_+&*-]+)*@" + "(?:[a-zA-Z0-9-]+\\.)+[a-z"
				+ "A-Z]{2,7}$";
		Pattern pat = Pattern.compile(emailRegex);
		if (email == null)
			return false;
		return pat.matcher(email).matches();
	}

	@Override
	public void saveToFile(String filePath) {
		try {
			Customer customer = new Customer();
			customer.setTradingPartnerId(getTradingPartnerId());
			customer.setTradingPartnername(getTradingPartnername());
			customer.setCity(getCity());
			customer.setCreditLimit(getCreditLimit());
			customer.setEmailId(getEmailId());
			SerializationUtil.serialize(customer, filePath);
			System.out.println("Customer details exported successfully");
		} catch (Exception e) {
			System.err.println("ERROR SAVING USING BINARY SERIALIZATION");
			e.printStackTrace();
		}
	}

	public void saveToFileXML(String filePath) {
		try {
			Customer customer = new Customer();
			customer.setTradingPartnerId(getTradingPartnerId());
			customer.setTradingPartnername(getTradingPartnername());
			customer.setCity(getCity());
			customer.setCreditLimit(getCreditLimit());
			customer.setEmailId(getEmailId());
			SerializationUtil.serializeToXML(customer, filePath);
			System.out.println("Customer details exported successfully");
		} catch (Exception e) {
			System.err.println("ERROR SAVING USING XML SERIALIZATION");
			e.printStackTrace();
		}
	}

	public Long getCreditLimit() {
		return creditLimit;
	}

	public void setCreditLimit(Long creditLimit) {
		this.creditLimit = creditLimit;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", creditLimit=" + creditLimit + ", emailId=" + emailId
				+ ", tradingPartnerId = " + super.tradingPartnerId + ", tradingPartnerName = "
				+ super.tradingPartnername + ", city = " + super.city + "]";
	}

}
