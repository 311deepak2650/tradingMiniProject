package com.citiustech.ApplicationEntities;

import java.util.ArrayList;

public abstract class TradingPartner {

	public Long tradingPartnerId;
	public String tradingPartnername;
	public String city;

	public ArrayList<String> validate() {
		ArrayList<String> errorList = new ArrayList<String>();
		try {
			if (getTradingPartnerId() == null) {
				errorList.add("Trading partner id is mandatory");
			} else if (getTradingPartnerId() < 0) {
				errorList.add("Trading partner id should be non negative");
			}
			if (getTradingPartnername() == null || "".equals(getTradingPartnername())) {
				errorList.add("Trading partner name is mandatory");
			} else if (getTradingPartnername() != null && !getTradingPartnername().matches("[a-zA-Z0-9]+")) {
				errorList.add("Trading partner name is invalid");
			} else if (getTradingPartnername() != null && getTradingPartnername().length() < 5) {
				errorList.add("Trading partner name should be atleast 5 characters in length");
			}
			if (getCity() == null || "".equals(getCity())) {
				errorList.add("Trading city is mandatory");
			} else if (getCity() != null && !getCity().matches("[a-zA-Z0-9]+")) {
				errorList.add("City is invalid");
			} else if (getCity() != null && getCity().length() < 3) {
				errorList.add("Trading city should be atleast 3 characters in length");
			}
			return errorList;
		} catch (Exception e) {
			System.err.println("ERROR WHILE VALIDATING : ");
			System.err.println(e);
			return null;
		}
	}

	public abstract void saveToFile(String filePath);

	public Long getTradingPartnerId() {
		return tradingPartnerId;
	}

	public void setTradingPartnerId(Long tradingPartnerId) {
		this.tradingPartnerId = tradingPartnerId;
	}

	public String getTradingPartnername() {
		return tradingPartnername;
	}

	public void setTradingPartnername(String tradingPartnername) {
		this.tradingPartnername = tradingPartnername;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "TradingPartner [tradingPartnerId=" + tradingPartnerId + ", tradingPartnername=" + tradingPartnername
				+ ", city=" + city + "]";
	}

}
