package com.citiustech.ApplicationEntities;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.regex.Pattern;

public class Supplier extends TradingPartner implements Serializable {

	private static final long serialVersionUID = 5256625433736136165L;
	public Long supplierId;
	public Long creditBalance;
	public String panNo;

	@Override
	public ArrayList<String> validate() {
		ArrayList<String> tradingErrors = super.validate();
		ArrayList<String> errorList;
		try {
			if (tradingErrors != null && !tradingErrors.isEmpty()) {
				errorList = tradingErrors;
			} else {
				errorList = new ArrayList<String>();
			}

			if (getCreditBalance() > 150000) {
				errorList.add("Credit Balance should not be more than 1,50,000");
			}
			if (!isPANValid(getPanNo())) {
				errorList.add("Invalid PAN Number");
			}
			return errorList;
		} catch (Exception e) {
			System.err.println("ERROR WHILE VALIDATING SUPPLIER : ");
			System.err.println(e);
			return null;
		}
	}

	public static boolean isPANValid(String pan) {
		String panRegex = "[A-Z]{5}[0-9]{4}[A-Z]{1}";
		Pattern pattern = Pattern.compile(panRegex);
		if (pan == null)
			return false;
		return pattern.matcher(pan).matches();
	}

	@Override
	public void saveToFile(String filePath) {
		try {
			Supplier supplier = new Supplier();
			supplier.setTradingPartnerId(getTradingPartnerId());
			supplier.setTradingPartnername(getTradingPartnername());
			supplier.setCity(getCity());
			supplier.setCreditBalance(getCreditBalance());
			supplier.setPanNo(getPanNo());
			SerializationUtil.serializeToXML(supplier, filePath);
			System.out.println("Supplier details exported successfully");
		} catch (Exception e) {
			System.err.println("ERROR SAVING USING XML SERIALIZATION");
			e.printStackTrace();
		}
	}

	public Long getCreditBalance() {
		return creditBalance;
	}

	public void setCreditBalance(Long creditBalance) {
		this.creditBalance = creditBalance;
	}

	public String getPanNo() {
		return panNo;
	}

	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}

	public Long getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(Long supplierId) {
		this.supplierId = supplierId;
	}

	@Override
	public String toString() {
		return "Supplier [supplierId=" + supplierId + ", creditBalance=" + creditBalance + ", panNo=" + panNo
				+ ", tradingPartnerId = " + super.tradingPartnerId + ", tradingPartnerName = "
				+ super.tradingPartnername + ", city = " + super.city + "]";
	}

}
