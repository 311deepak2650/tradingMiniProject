package com.citiustech.MyConsoleApplication;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.List;
import java.util.Scanner;

import com.citiustech.ApplicationEntities.Customer;
import com.citiustech.ApplicationEntities.Supplier;
import com.citiustech.Constants.IConstants;
import com.citiustech.ApplicationDAL.DALService;

public class MyConsoleApplication {

	public static void main(String[] args) throws Exception {
		Connection myConn = null;
		Scanner sc = null;
		try {
			// 1. Get a connection to database
			myConn = DriverManager.getConnection(IConstants.URL, IConstants.USER, IConstants.PASSWORD);
			sc = new Scanner(System.in);
			System.out.println("Welcome to Console Application");
			int action;
			do {
				System.out.println(
						"Press 1. Add Customer 2. Add Supplier 3. Show all customers 4. Show all suppliers 5. Export a customer 6. Export a supplier 7. Update a customer 8. Update a supplier 9. Exit");
				while (!sc.hasNextInt()) {
					System.out.println(IConstants.NOT_A_NUMBER);
					sc.next(); // this is important!
				}
				action = sc.nextInt();
				if (!(action >= 1 && action <= 9)) {
					System.out.println("Kindly enter number between 1 to 9");
				} else if (action == 1) {
					addCustomer(sc, myConn);
				} else if (action == 2) {
					addSupplier(sc, myConn);
				} else if (action == 3) {
					showAllCustomers(myConn);
				} else if (action == 4) {
					showAllSuppliers(myConn);
				} else if (action == 5) {
					int action2;
					do {
						System.out.println("Please enter 1. To Export in Binary 2. To Export in XML 3. Exit");
						while (!sc.hasNextInt()) {
							System.out.println(IConstants.NOT_A_NUMBER);
							sc.next(); // this is important!
						}
						action2 = sc.nextInt();
						if (!(action2 >= 1 && action2 <= 3)) {
							System.out.println("Kindly enter number between 1 to 3");
						} else if (action2 == 1) {
							exportACustomer(sc, myConn);
						} else if (action2 == 2) {
							exportACustomerXML(sc, myConn);
						}
					} while (action2 != 3);
				} else if (action == 6) {
					exportASupplier(sc, myConn);
				} else if (action == 7) {
					updateCustomerDetails(sc, myConn);
				} else if (action == 8) {
					updateSupplierDetails(sc, myConn);
				}
			} while (action != 9);
			System.out.println("Process terminated successfully !!");
		} catch (Exception e) {
			System.err.println("ERROR EXECUTING CONSOLE APPLICATION");
			e.printStackTrace();
		} finally {
			if (myConn != null) {
				myConn.close();
			}
			if (sc != null) {
				sc.close();
			}
		}
	}

	public static void updateSupplierDetails(Scanner sc, Connection connection) {
		Supplier supplier = null;
		DALService dalService;
		List<String> errorList;
		int action;
		Long creditBalance;
		String panNo;
		Long tradingPartnerId;
		String tradingPartnerName;
		String city;
		try {
			dalService = new DALService();
			System.out.println("Please enter supplier id to update");
			Long supplierId = sc.nextLong();
			supplier = dalService.getSupplierById(supplierId, connection);
			if (supplier != null) {
				do {
					System.out.println(
							"What you want to update ? Press 1. Credit Balance 2. PAN Number 3. Trading partner id 4. Trading partner name 5. City 6. Exit");
					while (!sc.hasNextInt()) {
						System.out.println(IConstants.NOT_A_NUMBER);
						sc.next(); // this is important!
					}
					action = sc.nextInt();
					if (!(action >= 1 && action <= 6)) {
						System.out.println("Kindly enter number between 1 to 6");
					} else if (action == 1) {
						System.out.println("Please enter credit balance");
						while (!sc.hasNextLong()) {
							System.out.println(IConstants.NOT_A_NUMBER);
							sc.next(); // this is important!
						}
						creditBalance = sc.nextLong();
						supplier.setCreditBalance(creditBalance);
					} else if (action == 2) {
						System.out.println("Please enter PAN Number");
						panNo = sc.next();
						supplier.setPanNo(panNo);
					} else if (action == 3) {
						System.out.println("Please enter Trading partner id");
						while (!sc.hasNextLong()) {
							System.out.println(IConstants.NOT_A_NUMBER);
							sc.next(); // this is important!
						}
						tradingPartnerId = sc.nextLong();
						supplier.setTradingPartnerId(tradingPartnerId);
					} else if (action == 4) {
						System.out.println("Please enter Trading partner name");
						tradingPartnerName = sc.next();
						supplier.setTradingPartnername(tradingPartnerName);
					} else if (action == 5) {
						System.out.println("Please enter city");
						city = sc.next();
						supplier.setCity(city);
					}
					if (action != 6) {
						errorList = supplier.validate();
						if (errorList != null && !errorList.isEmpty()) {
							System.out.println("Following is/are error message(s)");
							for (String string : errorList) {
								System.out.println("* \t" + string);
							}
						} else {
							dalService = new DALService();
							dalService.updateSupplierDetails(supplier, connection);
						}
					}
				} while (action != 6);
			} else {
				System.out.println("No record found for provided supplier id");
			}
		} catch (Exception e) {
			System.err.println("ERROR UPDATING SUPPLIER DETIALS");
			e.printStackTrace();
		}
	}

	public static void updateCustomerDetails(Scanner sc, Connection connection) {
		Customer customer = null;
		DALService dalService;
		List<String> errorList;
		int action;
		Long creditLimit;
		String emailId;
		Long tradingPartnerId;
		String tradingPartnerName;
		String city;
		try {
			dalService = new DALService();
			System.out.println("Please enter customer id to update");
			Long customerId = sc.nextLong();
			customer = dalService.getCustomerById(customerId, connection);
			if (customer != null) {
				do {
					System.out.println(
							"What you want to update ? Press 1. Credit Limit 2. Email Id 3. Trading partner id 4. Trading partner name 5. City 6. Exit");
					while (!sc.hasNextInt()) {
						System.out.println(IConstants.NOT_A_NUMBER);
						sc.next(); // this is important!
					}
					action = sc.nextInt();
					if (!(action >= 1 && action <= 6)) {
						System.out.println("Kindly enter number between 1 to 6");
					} else if (action == 1) {
						System.out.println("Please enter credit limit");
						while (!sc.hasNextLong()) {
							System.out.println(IConstants.NOT_A_NUMBER);
							sc.next(); // this is important!
						}
						creditLimit = sc.nextLong();
						customer.setCreditLimit(creditLimit);
					} else if (action == 2) {
						System.out.println("Please enter email id");
						emailId = sc.next();
						customer.setEmailId(emailId);
					} else if (action == 3) {
						System.out.println("Please enter Trading partner id");
						while (!sc.hasNextLong()) {
							System.out.println(IConstants.NOT_A_NUMBER);
							sc.next(); // this is important!
						}
						tradingPartnerId = sc.nextLong();
						customer.setTradingPartnerId(tradingPartnerId);
					} else if (action == 4) {
						System.out.println("Please enter Trading partner name");
						tradingPartnerName = sc.next();
						customer.setTradingPartnername(tradingPartnerName);
					} else if (action == 5) {
						System.out.println("Please enter city");
						city = sc.next();
						customer.setCity(city);
					}
					if (action != 6) {
						errorList = customer.validate();
						if (errorList != null && !errorList.isEmpty()) {
							System.out.println("Following is/are error message(s)");
							for (String string : errorList) {
								System.out.println("* \t" + string);
							}
						} else {
							dalService = new DALService();
							dalService.updateCustomerDetails(customer, connection);
						}
					}
				} while (action != 6);
			} else {
				System.out.println("No record found for provided customer id");
			}
		} catch (Exception e) {
			System.err.println("ERROR UPDATING CUSTOMER DETIALS");
			e.printStackTrace();
		}
	}

	public static void exportASupplier(Scanner sc, Connection connection) {
		DALService dalService;
		Supplier supplier = null;
		try {
			dalService = new DALService();
			System.out.println("Please enter supplier id ");
			while (!sc.hasNextLong()) {
				System.out.println(IConstants.NOT_A_NUMBER);
				sc.next(); // this is important!
			}
			Long supplierId = sc.nextLong();
			supplier = dalService.getSupplierById(supplierId, connection);
			if (supplier != null) {
				String filePath = "supplier_" + supplier.getSupplierId() + ".xml";
				supplier.saveToFile(filePath);
			} else {
				System.out.println("No record found for provided supplier id");
			}
		} catch (Exception e) {
			System.err.println("ERROR EXPORTING SUPPLIER DETIALS");
			e.printStackTrace();
		}
	}

	public static void exportACustomerXML(Scanner sc, Connection connection) {
		DALService dalService;
		Customer customer = null;
		try {
			dalService = new DALService();
			System.out.println("Please enter customer id ");
			while (!sc.hasNextLong()) {
				System.out.println(IConstants.NOT_A_NUMBER);
				sc.next(); // this is important!
			}
			Long customerId = sc.nextLong();
			customer = dalService.getCustomerById(customerId, connection);
			if (customer != null) {
				String filePath = "customer_" + customer.getCustomerId() + ".xml";
				customer.saveToFileXML(filePath);
			} else {
				System.out.println("No record found for provided customer id");
			}
		} catch (Exception e) {
			System.err.println("ERROR EXPORTING CUSTOMER DETIALS");
			e.printStackTrace();
		}
	}

	public static void exportACustomer(Scanner sc, Connection connection) {
		DALService dalService;
		Customer customer = null;
		try {
			dalService = new DALService();
			System.out.println("Please enter customer id ");
			while (!sc.hasNextLong()) {
				System.out.println(IConstants.NOT_A_NUMBER);
				sc.next(); // this is important!
			}
			Long customerId = sc.nextLong();
			customer = dalService.getCustomerById(customerId, connection);
			if (customer != null) {
				String filePath = "customer_" + customer.getCustomerId() + ".txt";
				customer.saveToFile(filePath);
			} else {
				System.out.println("No record found for provided customer id");
			}
		} catch (Exception e) {
			System.err.println("ERROR EXPORTING CUSTOMER DETIALS");
			e.printStackTrace();
		}
	}

	public static void showAllCustomers(Connection connection) {
		DALService dalService;
		List<Customer> customers;
		try {
			dalService = new DALService();
			customers = dalService.getAllCustomers(connection);
			if (customers != null && !customers.isEmpty()) {
				System.out.println("Following is the customer details");
				for (Customer customer : customers) {
					System.out.println(customer);
				}
			} else {
				System.out.println("No record found for customers");
			}
		} catch (Exception e) {
			System.err.println("ERROR FETCHING ALL CUSTOMER DETAILS");
			e.printStackTrace();
		}
	}

	public static void showAllSuppliers(Connection connection) {
		DALService dalService;
		List<Supplier> suppliers;
		try {
			dalService = new DALService();
			suppliers = dalService.getAllSuppliers(connection);
			if (suppliers != null && !suppliers.isEmpty()) {
				System.out.println("Following is the supplier details");
				for (Supplier supplier : suppliers) {
					System.out.println(supplier);
				}
			} else {
				System.out.println("No record found for suppliers");
			}
		} catch (Exception e) {
			System.err.println("ERROR FETCHING ALL SUPPLIER DETAILS");
			e.printStackTrace();
		}
	}

	public static void addSupplier(Scanner sc, Connection connection) {
		Supplier supplier;
		List<String> errorList;
		DALService dalService;
		try {
			supplier = new Supplier();
			System.out.println("Kindly enter supplier details");
			System.out.println("Please enter credit balance");
			while (!sc.hasNextLong()) {
				System.out.println(IConstants.NOT_A_NUMBER);
				sc.next(); // this is important!
			}
			Long creditBalance = sc.nextLong();
			System.out.println("Please enter PAN number");
			String panNo = sc.next();
			System.out.println("Please enter trading partner id");
			while (!sc.hasNextLong()) {
				System.out.println(IConstants.NOT_A_NUMBER);
				sc.next(); // this is important!
			}
			Long tradingPartnerId = sc.nextLong();
			System.out.println("Please enter trading partner name");
			String tradingPartnerName = sc.next();
			System.out.println("Please enter city");
			String city = sc.next();
			supplier.setCreditBalance(creditBalance);
			supplier.setPanNo(panNo);
			supplier.setTradingPartnerId(tradingPartnerId);
			supplier.setTradingPartnername(tradingPartnerName);
			supplier.setCity(city);
			errorList = supplier.validate();
			if (errorList != null && !errorList.isEmpty()) {
				System.out.println("Following is/are error message(s)");
				for (String string : errorList) {
					System.out.println("* \t" + string);
				}
			} else {
				dalService = new DALService();
				dalService.saveSupplierDetails(supplier, connection);
			}
		} catch (Exception e) {
			System.err.println("CONSOLE : ERROR ADDING SUPPLIER");
			e.printStackTrace();
		}
	}

	public static void addCustomer(Scanner sc, Connection connection) {
		Customer customer;
		List<String> errorList;
		DALService dalService;
		try {
			customer = new Customer();
			System.out.println("Kindly enter customer details");
			System.out.println("Please enter credit limit");
			while (!sc.hasNextLong()) {
				System.out.println(IConstants.NOT_A_NUMBER);
				sc.next(); // this is important!
			}
			Long creditLimit = sc.nextLong();
			System.out.println("Please enter email id");
			String emailId = sc.next();
			System.out.println("Please enter trading partner id");
			while (!sc.hasNextLong()) {
				System.out.println(IConstants.NOT_A_NUMBER);
				sc.next(); // this is important!
			}
			Long tradingPartnerId = sc.nextLong();
			System.out.println("Please enter trading partner name");
			String tradingPartnerName = sc.next();
			System.out.println("Please enter city");
			String city = sc.next();

			customer.setCreditLimit(creditLimit);
			customer.setEmailId(emailId);
			customer.setTradingPartnerId(tradingPartnerId);
			customer.setTradingPartnername(tradingPartnerName);
			customer.setCity(city);
			errorList = customer.validate();
			if (errorList != null && !errorList.isEmpty()) {
				System.out.println("Following is/are error message(s)");
				for (String string : errorList) {
					System.out.println("* \t" + string);
				}
			} else {
				dalService = new DALService();
				dalService.saveCustomerDetails(customer, connection);
			}
		} catch (Exception e) {
			System.err.println("CONSOLE : ERROR ADDING CUSTOMER");
			e.printStackTrace();
		}
	}
}
