package com.citiustech.Constants;

public class IConstants {

	public static final String URL = "jdbc:mysql://localhost:3306/trading";
	public static final String USER = "root";
	public static final String PASSWORD = "root";
	public static final String NOT_A_NUMBER = "That's not a number";
}
