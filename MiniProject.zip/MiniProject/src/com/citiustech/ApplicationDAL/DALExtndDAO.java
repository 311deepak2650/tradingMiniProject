package com.citiustech.ApplicationDAL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.citiustech.ApplicationEntities.Customer;
import com.citiustech.ApplicationEntities.Supplier;

public class DALExtndDAO {

	public void updateSupplierDetails(Supplier supplier, Connection connection) throws SQLException {
		PreparedStatement myStmt = null;
		try {
			// 2. Create a statement
			String sql = "update supplier set trading_partner_id = ?,trading_partner_name = ?,city = ?,credit_balance=?,pan_no=? where supplier_id = ?";
			myStmt = connection.prepareStatement(sql);
			// set param values
			myStmt.setLong(1, supplier.getTradingPartnerId());
			myStmt.setString(2, supplier.getTradingPartnername());
			myStmt.setString(3, supplier.getCity());
			myStmt.setLong(4, supplier.getCreditBalance());
			myStmt.setString(5, supplier.getPanNo());
			myStmt.setLong(6, supplier.getSupplierId());
			// 3. Execute SQL query
			myStmt.executeUpdate();
			System.out.println("Update complete.");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (myStmt != null) {
				myStmt.close();
			}
		}
	}

	public void updateCustomerDetails(Customer customer, Connection connection) throws SQLException {
		PreparedStatement myStmt = null;
		try {
			// 2. Create a statement
			String sql = "update customer set trading_partner_id = ?,trading_partner_name = ?,city = ?,credit_limit=?,email_id=? where customer_id = ?";
			myStmt = connection.prepareStatement(sql);
			// set param values
			myStmt.setLong(1, customer.getTradingPartnerId());
			myStmt.setString(2, customer.getTradingPartnername());
			myStmt.setString(3, customer.getCity());
			myStmt.setLong(4, customer.getCreditLimit());
			myStmt.setString(5, customer.getEmailId());
			myStmt.setLong(6, customer.getCustomerId());
			// 3. Execute SQL query
			myStmt.executeUpdate();
			System.out.println("Update complete.");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (myStmt != null) {
				myStmt.close();
			}
		}
	}

	public void saveCustomerDetails(Customer customer, Connection connection) throws SQLException {
		PreparedStatement myStmt = null;
		try {
			// 2. Create a statement
			String sql = "insert into customer "
					+ " (trading_partner_id, trading_partner_name, city, credit_limit, email_id)"
					+ " values (?, ?, ?, ?, ?)";
			myStmt = connection.prepareStatement(sql);
			// set param values
			myStmt.setLong(1, customer.getTradingPartnerId());
			myStmt.setString(2, customer.getTradingPartnername());
			myStmt.setString(3, customer.getCity());
			myStmt.setLong(4, customer.getCreditLimit());
			myStmt.setString(5, customer.getEmailId());
			// 3. Execute SQL query
			myStmt.executeUpdate();
			System.out.println("Insert complete.");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (myStmt != null) {
				myStmt.close();
			}
		}
	}

	public void saveSupplierDetails(Supplier supplier, Connection connection) throws SQLException {
		PreparedStatement myStmt = null;
		try {
			// 2. Create a statement
			String sql = "insert into supplier "
					+ " (trading_partner_id, trading_partner_name, city, credit_balance, pan_no)"
					+ " values (?, ?, ?, ?, ?)";
			myStmt = connection.prepareStatement(sql);
			// set param values
			myStmt.setLong(1, supplier.getTradingPartnerId());
			myStmt.setString(2, supplier.getTradingPartnername());
			myStmt.setString(3, supplier.getCity());
			myStmt.setLong(4, supplier.getCreditBalance());
			myStmt.setString(5, supplier.getPanNo());
			// 3. Execute SQL query
			myStmt.executeUpdate();
			System.out.println("Insert complete.");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (myStmt != null) {
				myStmt.close();
			}

		}
	}

	public List<Customer> getAllCustomers(Connection connection) {
		Statement stmt = null;
		Customer customer;
		List<Customer> customers;
		try {
			customers = new ArrayList<>();
			stmt = connection.createStatement();
			String sql = "SELECT * FROM customer";
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {
				customer = new Customer();
				customer.setCustomerId(Long.valueOf(rs.getInt(1)));
				customer.setCreditLimit(Long.valueOf(rs.getInt(2)));
				customer.setEmailId(rs.getString(3));
				customer.setTradingPartnerId(Long.valueOf(rs.getInt(4)));
				customer.setTradingPartnername(rs.getString(5));
				customer.setCity(rs.getString(6));
				customers.add(customer);
			}
			rs.close();
			return customers;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public List<Supplier> getAllSuppliers(Connection connection) {
		Statement stmt = null;
		Supplier supplier;
		List<Supplier> suppliers;
		try {
			suppliers = new ArrayList<>();
			stmt = connection.createStatement();
			String sql = "SELECT * FROM supplier";
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {
				supplier = new Supplier();
				supplier.setSupplierId(Long.valueOf(rs.getInt(1)));
				supplier.setCreditBalance(Long.valueOf(rs.getInt(2)));
				supplier.setPanNo(rs.getString(3));
				supplier.setTradingPartnerId(Long.valueOf(rs.getInt(4)));
				supplier.setTradingPartnername(rs.getString(5));
				supplier.setCity(rs.getString(6));
				suppliers.add(supplier);
			}
			rs.close();
			return suppliers;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public Customer getCustomerById(Long customerId, Connection connection) {
		PreparedStatement myStmt = null;
		Customer customer = null;
		try {
			// 2. Create a statement
			String sql = "select * from customer where customer_id = ?";
			myStmt = connection.prepareStatement(sql);
			myStmt.setLong(1, customerId);
			ResultSet rs = myStmt.executeQuery();
			while (rs.next()) {
				customer = new Customer();
				customer.setCustomerId(Long.valueOf(rs.getInt(1)));
				customer.setCreditLimit(Long.valueOf(rs.getInt(2)));
				customer.setEmailId(rs.getString(3));
				customer.setTradingPartnerId(Long.valueOf(rs.getInt(4)));
				customer.setTradingPartnername(rs.getString(5));
				customer.setCity(rs.getString(6));
			}
			rs.close();
			return customer;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public Supplier getSupplierById(Long supplierId, Connection connection) {
		PreparedStatement myStmt = null;
		Supplier supplier = null;
		try {
			// 2. Create a statement
			String sql = "select * from supplier where supplier_id = ?";
			myStmt = connection.prepareStatement(sql);
			myStmt.setLong(1, supplierId);
			ResultSet rs = myStmt.executeQuery();
			while (rs.next()) {
				supplier = new Supplier();
				supplier.setSupplierId(Long.valueOf(rs.getInt(1)));
				supplier.setCreditBalance(Long.valueOf(rs.getInt(2)));
				supplier.setPanNo(rs.getString(3));
				supplier.setTradingPartnerId(Long.valueOf(rs.getInt(4)));
				supplier.setTradingPartnername(rs.getString(5));
				supplier.setCity(rs.getString(6));
			}
			rs.close();
			return supplier;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
}
