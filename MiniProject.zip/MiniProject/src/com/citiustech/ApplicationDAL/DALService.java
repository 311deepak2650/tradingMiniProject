package com.citiustech.ApplicationDAL;

import java.sql.Connection;
import java.util.List;

import com.citiustech.ApplicationEntities.Customer;
import com.citiustech.ApplicationEntities.Supplier;
import com.citiustech.ApplicationDAL.DALExtndDAO;

public class DALService {
	
	public void updateSupplierDetails(Supplier supplier, Connection connection) {
		DALExtndDAO dao;
		try {
			dao = new DALExtndDAO();
			dao.updateSupplierDetails(supplier, connection);
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("ERROR UPDATING SUPPLIER DATA");
		}
	}
	
	public void updateCustomerDetails(Customer customer, Connection connection) {
		DALExtndDAO dao;
		try {
			dao = new DALExtndDAO();
			dao.updateCustomerDetails(customer, connection);
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("ERROR UPDATING CUSTOMER DATA");
		}
	}

	public void saveCustomerDetails(Customer customer, Connection connection) {
		DALExtndDAO dao;
		try {
			dao = new DALExtndDAO();
			dao.saveCustomerDetails(customer, connection);
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("ERROR SAVING CUSTOMER DATA");
		}
	}

	public void saveSupplierDetails(Supplier supplier, Connection connection) {
		DALExtndDAO dao;
		try {
			dao = new DALExtndDAO();
			dao.saveSupplierDetails(supplier, connection);
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("ERROR SAVING SUPPLIER DATA");
		}
	}

	public List<Customer> getAllCustomers(Connection connection) {
		DALExtndDAO dao;
		List<Customer> list;
		try {
			dao = new DALExtndDAO();
			list = dao.getAllCustomers(connection);
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("ERROR FETCHING ALL THE CUSTOMERS");
			throw e;
		}
	}

	public List<Supplier> getAllSuppliers(Connection connection) {
		DALExtndDAO dao;
		List<Supplier> list;
		try {
			dao = new DALExtndDAO();
			list = dao.getAllSuppliers(connection);
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("ERROR FETCHING ALL THE SUPPLIERS");
			throw e;
		}
	}

	public Customer getCustomerById(Long customerId, Connection connection) {
		DALExtndDAO dao;
		Customer customer;
		try {
			dao = new DALExtndDAO();
			customer = dao.getCustomerById(customerId, connection);
			return customer;
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("ERROR FETCHING CUSTOMER");
			throw e;
		}
	}

	public Supplier getSupplierById(Long supplierId, Connection connection) {
		DALExtndDAO dao;
		Supplier supplier;
		try {
			dao = new DALExtndDAO();
			supplier = dao.getSupplierById(supplierId, connection);
			return supplier;
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("ERROR FETCHING SUPPLIER");
			throw e;
		}
	}
}
